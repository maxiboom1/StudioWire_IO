import { createDefaultSettings, DEFAULT_CABLE_NUMBER_PADDING } from './defaults';
import { formatCableNumber, makeId, makeIndexedId, nowIso } from './id';
import { STUDIOWIRE_SCHEMA_VERSION } from './types';
import type {
  Cable,
  CableStatus,
  Device,
  DeviceMountType,
  Endpoint,
  Location,
  NumberingLedger,
  NumberingRange,
  Port,
  PortDirection,
  PortGroup,
  ProjectInfo,
  ProjectRoot,
  ProjectStatus,
  Rack,
  RackNumberingDirection,
} from './types';

const UNKNOWN_ENDPOINT: Endpoint = {
  type: 'unknown',
  id: null,
  label: 'Unknown',
};

export interface ProjectInfoInput {
  id?: string;
  name: string;
  customer?: string;
  revision?: string;
  status?: ProjectStatus;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
}

export function createProjectInfo(input: ProjectInfoInput): ProjectInfo {
  const timestamp = nowIso();

  return {
    id: input.id ?? makeId('project', input.name),
    name: input.name,
    customer: input.customer ?? '',
    revision: input.revision ?? '0.1',
    status: input.status ?? 'draft',
    createdAt: input.createdAt ?? timestamp,
    updatedAt: input.updatedAt ?? timestamp,
    createdBy: input.createdBy ?? 'local',
    updatedBy: input.updatedBy ?? 'local',
  };
}

export function createEmptyProject(input: ProjectInfoInput): ProjectRoot {
  const project = createProjectInfo(input);

  return {
    schemaVersion: STUDIOWIRE_SCHEMA_VERSION,
    project,
    settings: createDefaultSettings(),
    locations: [],
    racks: [],
    devices: [],
    portGroups: [],
    ports: [],
    cables: [],
    numberingLedgers: [],
    validationIssues: [],
    changeLog: [
      {
        id: makeId('change', `${project.id}-created`),
        timestamp: project.createdAt,
        message: 'Project created',
        author: project.createdBy,
      },
    ],
  };
}

export interface LocationInput {
  id?: string;
  name: string;
  type?: string;
  description?: string;
}

export function createLocation(input: LocationInput): Location {
  return {
    id: input.id ?? makeId('location', input.name),
    name: input.name,
    type: input.type ?? '',
    description: input.description ?? '',
  };
}

export interface RackInput {
  id?: string;
  locationId: string;
  name: string;
  heightRu?: number;
  numberingDirection?: RackNumberingDirection;
}

export function createRack(input: RackInput): Rack {
  return {
    id: input.id ?? makeId('rack', input.name),
    locationId: input.locationId,
    name: input.name,
    heightRu: input.heightRu ?? 42,
    numberingDirection: input.numberingDirection ?? 'bottom_to_top',
  };
}

export interface DeviceInput {
  id?: string;
  name: string;
  code?: string;
  manufacturer?: string;
  model?: string;
  categoryId: string;
  locationId: string;
  role?: string;
  labelPrefix?: string;
  mountType?: DeviceMountType;
  rackId?: string | null;
  rackSizeRu?: number | null;
  rackBottomRu?: number | null;
  status?: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export function createDevice(input: DeviceInput): Device {
  const timestamp = nowIso();

  return {
    id: input.id ?? makeId('device', input.name),
    name: input.name,
    code: input.code ?? '',
    manufacturer: input.manufacturer ?? '',
    model: input.model ?? '',
    categoryId: input.categoryId,
    locationId: input.locationId,
    role: input.role ?? '',
    labelPrefix: input.labelPrefix ?? input.code ?? '',
    mountType: input.mountType ?? 'non_rack',
    rackId: input.rackId ?? null,
    rackSizeRu: input.rackSizeRu ?? null,
    rackBottomRu: input.rackBottomRu ?? null,
    status: input.status ?? 'planned',
    notes: input.notes ?? '',
    createdAt: input.createdAt ?? timestamp,
    updatedAt: input.updatedAt ?? timestamp,
  };
}

export interface PortGroupInput {
  id?: string;
  deviceId: string;
  name: string;
  direction: PortDirection;
  categoryId: string;
  connectorTypeId: string;
  count: number;
  portLabelPattern?: string;
  cablePrefix: string;
  firstCableNumber?: number | null;
  lastCableNumber?: number | null;
  numberingRangeId?: string | null;
  createPlannedCables?: boolean;
  locked?: boolean;
}

export function createPortGroup(input: PortGroupInput): PortGroup {
  const id = input.id ?? makeId('port-group', `${input.deviceId}-${input.name}`);

  return {
    id,
    deviceId: input.deviceId,
    name: input.name,
    direction: input.direction,
    categoryId: input.categoryId,
    connectorTypeId: input.connectorTypeId,
    count: input.count,
    portLabelPattern: input.portLabelPattern ?? '{name} {index}',
    cablePrefix: input.cablePrefix,
    firstCableNumber: input.firstCableNumber ?? null,
    lastCableNumber: input.lastCableNumber ?? null,
    numberingRangeId: input.numberingRangeId ?? null,
    createPlannedCables: input.createPlannedCables ?? false,
    locked: input.locked ?? false,
  };
}

export function createPortsForGroup(portGroup: PortGroup): Port[] {
  return Array.from({ length: portGroup.count }, (_, offset) => {
    const index = offset + 1;
    const label = portGroup.portLabelPattern
      .replace('{name}', portGroup.name)
      .replace('{index}', String(index).padStart(2, '0'));

    return {
      id: makeIndexedId(`${portGroup.id}-port`, index),
      deviceId: portGroup.deviceId,
      portGroupId: portGroup.id,
      index,
      name: `${portGroup.name} ${index}`,
      label,
      direction: portGroup.direction,
      categoryId: portGroup.categoryId,
      connectorTypeId: portGroup.connectorTypeId,
      plannedCableId: null,
      notes: '',
    };
  });
}

export interface PlannedCablesInput {
  portGroup: PortGroup;
  ports: Port[];
  status?: CableStatus;
}

export function createPlannedCablesForPorts(input: PlannedCablesInput): Cable[] {
  const { portGroup, ports } = input;

  if (!portGroup.createPlannedCables || portGroup.firstCableNumber === null) {
    return [];
  }

  return ports.map((port, offset) => {
    const index = portGroup.firstCableNumber ?? 1;
    const cableIndex = index + offset;
    const cableNumber = formatCableNumber(
      portGroup.cablePrefix,
      cableIndex,
      DEFAULT_CABLE_NUMBER_PADDING,
    );

    return {
      id: makeId('cable', cableNumber),
      number: cableNumber,
      prefix: portGroup.cablePrefix,
      index: cableIndex,
      status: input.status ?? 'planned',
      sourceEndpoint:
        port.direction === 'output'
          ? { type: 'device_port', id: port.id, label: port.label }
          : UNKNOWN_ENDPOINT,
      destinationEndpoint:
        port.direction === 'input'
          ? { type: 'device_port', id: port.id, label: port.label }
          : UNKNOWN_ENDPOINT,
      labelTop: cableNumber,
      labelMiddle: port.label,
      labelBottom: '',
      notes: '',
    };
  });
}

export interface NumberingLedgerInput {
  prefix: string;
  nextSuggested: number;
  ranges?: NumberingRange[];
}

export function createNumberingLedger(input: NumberingLedgerInput): NumberingLedger {
  return {
    prefix: input.prefix,
    nextSuggested: input.nextSuggested,
    ranges: input.ranges ?? [],
  };
}
